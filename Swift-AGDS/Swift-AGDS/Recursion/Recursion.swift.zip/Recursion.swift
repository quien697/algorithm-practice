//
//  Resursion.swift
//  Swift-AGDS
//
//  Created by Quien on 2023/3/10.
//

import Foundation

// 1. Power(base, exponent): base^exponent
// assume exponent >= 0
func power(base: Int, exponent: Int) -> Int {
  assert(exponent >= 0)
  // base case
  if exponent == 0 { return 1 }
  // recursive case
  return base * power(base: base, exponent: exponent - 1)
}


// 2. isPalindrome(word): checks if a word is palindrome
func isPalindrome(word: String) -> Bool {
  // base
  if word.count <= 1 { return true }
  // recursion
  if let first = word.first, let last = word.last, first == last {
    let s = word.index(after: word.startIndex)
    let l = word.index(before: word.endIndex)
    return isPalindrome(word: String(word[s..<l]))
  }
  return false
}

// 3. printBinary(n): prints binary form of given int
func printBinary(_ n: Int) {
  if n > 0 {
    printBinary(n / 2)
    printBinaryHelper(n)
  } else if n < 0 {
    printBinary(n * -1 / 2)
    printBinaryHelper(n * -1, str: "-")
  }
}

func printBinaryHelper(_ n: Int, str: String = ""){
  print("\(str)\(n % 2)", terminator: "")
}

// 4. reverseLines
// - Print all lines in reverse order (recursively) from a text file
// - You can change the function header if you want
func loadFile(path: String, reverseLines: Bool) {
  guard let content = try? String(contentsOfFile: path) else {
    print("Can not find the file.")
    return
  }
  
  guard reverseLines else {
    print(content)
    return
  }
  
  let lines = content.components(separatedBy: "\n")
  reverseLinesHelper(lines: lines, index: lines.count-1)
}

func reverseLinesHelper(lines: [String], index: Int) {
  if index >= 0 {
    print(lines[index])
    reverseLinesHelper(lines: lines, index: index-1)
  }
}

// 5. evaluate
// Write a recursive function evaluate that accepts a string representing a math expression and computes its value.
// - The expression will be "fully parenthesized" and will consist of + and * on single-digit integers only.
// - You can use a helper function. (Do not change the original function header)
// - Use Recursion
//
// Examples)
// evaluate("7")                 -> 7
// evaluate("(2+2)")             -> 4
// evaluate("(1+(2*4))")         -> 9
// evaluate("((1+3)+((1+2)*5))") -> 19
func evaluate(_ expr: String) -> Int {
  print("count= \(expr.count)")
  evaluateHelper(expr, index: expr.index(before: expr.endIndex))
  return 0
}

func evaluateHelper(_ expr: String, index: String.Index) -> Int {
  print(expr[index])
  return 0
}
