//
//  LCA.swift
//  Swift-AGDS
//
//  Created by Quien on 2023/4/4.
//

import Foundation

// Lowest Common Ancestor
func lca() {
  func bfs(start: Int, adjList: inout [[Int]], visited: inout [Bool], parent: inout [Int]) {
    let queue = Queue<(Int)>()
    queue.enqueue(item: start)
    visited[start] = true
    while !queue.isEmpty() {
      if let u = queue.dequeue() {
        for v in adjList[u] {
          if !visited[v] {
            visited[v] = true
            parent[v] = u
            queue.enqueue(item: v)
          }
        }
      }
    }
  }
  
  func findAncestor(_ p: Int, _ q: Int) {
    if parent[p] == parent[q] {
      result.append(parent[p])
    } else if p == parent[q] {
      result.append(p)
    } else {
      if parent[p] != start {
        findAncestor(parent[p], q)
      } else if parent[q] != start {
        findAncestor(p, parent[q])
      } else {
        findAncestor(p, q)
      }
    }
  }
  
  let n = Int(readLine()!)!
  var m = n - 1
  var adjList = [[Int]](repeating: [], count: n + 1)
  
  for _ in 0..<m {
    let edge = readLine()!.split(separator: " ").map { Int($0)! }
    let u = edge[0]
    let v = edge[1]
    adjList[u].append(v)
    adjList[v].append(u)
  }
  
  var queryList = [[Int]]()
  m = Int(readLine()!)!
  for _ in 0..<m {
    let node = readLine()!.split(separator: " ").map { Int($0)! }
    queryList.append([node[0], node[1]])
  }
  
  var visited = [Bool](repeating: false, count: n + 1)
  var parent = [Int](repeating: 0, count: n + 1)
  let start = 1
  bfs(start: start, adjList: &adjList, visited: &visited, parent: &parent)
  
  var result = [Int]()
  for i in queryList {
    findAncestor(i[0], i[1])
  }
  
  for i in result {
    print(i)
  }
  
}
